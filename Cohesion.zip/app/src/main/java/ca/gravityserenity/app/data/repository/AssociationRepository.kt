package ca.gravityserenity.app.data.repository

import ca.gravityserenity.app.data.model.Association
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

class AssociationRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun getAssociation(associationId: String): Association? {
        val doc = db.collection("associations").document(associationId).get().await()
        return doc.toObject(Association::class.java)?.copy(id = doc.id)
    }

    suspend fun setWhatsappGroupLink(associationId: String, link: String) {
        db.collection("associations").document(associationId)
            .update("whatsappGroupLink", link).await()
    }
}
