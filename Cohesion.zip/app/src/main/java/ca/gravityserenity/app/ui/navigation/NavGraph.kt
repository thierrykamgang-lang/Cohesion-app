package ca.gravityserenity.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ca.gravityserenity.app.ui.screens.auth.AuthViewModel
import ca.gravityserenity.app.ui.screens.auth.LoginScreen
import ca.gravityserenity.app.ui.screens.auth.SignUpScreen
import ca.gravityserenity.app.ui.screens.chat.ChatScreen
import ca.gravityserenity.app.ui.screens.members.MemberEditScreen
import ca.gravityserenity.app.ui.screens.members.MembersListScreen
import ca.gravityserenity.app.ui.screens.members.MembersViewModel

sealed class Screen(val route: String) {
    data object Login : Screen("login")
    data object SignUp : Screen("signup")
    data object MembersList : Screen("members_list")
    data object MemberAdd : Screen("member_add")
    data object Chat : Screen("chat")
    data object MemberEdit : Screen("member_edit/{memberId}") {
        fun createRoute(memberId: String) = "member_edit/$memberId"
        val arguments: List<NamedNavArgument> = listOf(
            navArgument("memberId") { type = NavType.StringType }
        )
    }
}

// Routes that show the bottom nav bar (i.e. everything past login).
private val mainTabs = listOf(
    Triple(Screen.MembersList.route, "Members", Icons.Default.People),
    Triple(Screen.Chat.route, "Chat", Icons.Default.Chat)
)

@Composable
fun GsNavGraph(navController: NavHostController = rememberNavController()) {
    val authViewModel: AuthViewModel = viewModel()
    val membersViewModel: MembersViewModel = viewModel()
    val authState by authViewModel.uiState.collectAsState()

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = authState.isLoggedIn && currentRoute in mainTabs.map { it.first }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    mainTabs.forEach { (route, label, icon) ->
                        NavigationBarItem(
                            selected = currentRoute == route,
                            onClick = {
                                navController.navigate(route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = if (authState.isLoggedIn) Screen.MembersList.route else Screen.Login.route,
            modifier = androidx.compose.ui.Modifier.padding(padding)
        ) {

            composable(Screen.Login.route) {
                LoginScreen(
                    viewModel = authViewModel,
                    onLoggedIn = {
                        navController.navigate(Screen.MembersList.route) {
                            popUpTo(Screen.Login.route) { inclusive = true }
                        }
                    },
                    onGoToSignUp = { navController.navigate(Screen.SignUp.route) }
                )
            }

            composable(Screen.SignUp.route) {
                SignUpScreen(
                    viewModel = authViewModel,
                    onSignedUp = {
                        navController.navigate(Screen.MembersList.route) {
                            popUpTo(Screen.Login.route) { inclusive = true }
                        }
                    },
                    onGoToLogin = { navController.popBackStack() }
                )
            }

            composable(Screen.MembersList.route) {
                MembersListScreen(
                    viewModel = membersViewModel,
                    onMemberClick = { member ->
                        navController.navigate(Screen.MemberEdit.createRoute(member.id))
                    },
                    onAddMemberClick = { navController.navigate(Screen.MemberAdd.route) }
                )
            }

            composable(Screen.MemberAdd.route) {
                MemberEditScreen(
                    existingMember = null,
                    viewModel = membersViewModel,
                    onDone = { navController.popBackStack() }
                )
            }

            composable(Screen.MemberEdit.route, arguments = Screen.MemberEdit.arguments) { backStackEntry ->
                val memberId = backStackEntry.arguments?.getString("memberId")
                val state by membersViewModel.uiState.collectAsState()
                val existing = remember(memberId, state.members) {
                    state.members.find { it.id == memberId }
                }

                MemberEditScreen(
                    existingMember = existing,
                    viewModel = membersViewModel,
                    onDone = { navController.popBackStack() }
                )
            }

            composable(Screen.Chat.route) {
                ChatScreen()
            }
        }
    }
}
