package ca.gravityserenity.app.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ca.gravityserenity.app.data.model.Member
import ca.gravityserenity.app.data.model.MemberRole
import ca.gravityserenity.app.data.model.MemberStatus
import ca.gravityserenity.app.data.repository.AuthRepository
import ca.gravityserenity.app.data.repository.MemberRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val isLoading: Boolean = false,
    val isLoggedIn: Boolean = false,
    val errorMessage: String? = null
)

class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository(),
    private val memberRepository: MemberRepository = MemberRepository(),
    private val associationId: String = "demo-association" // TODO: replace with real association selection/invite-code flow
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState(isLoggedIn = authRepository.isLoggedIn()))
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun signIn(email: String, password: String) {
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = authRepository.signIn(email, password)
            result.fold(
                onSuccess = { _uiState.value = AuthUiState(isLoggedIn = true) },
                onFailure = { e ->
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = e.message)
                }
            )
        }
    }

    fun signUp(fullName: String, email: String, password: String) {
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = authRepository.signUp(email, password)
            result.fold(
                onSuccess = { user ->
                    // New members start PENDING_APPROVAL so an admin/exec approves them
                    // before they can see association data (enforce this in Firestore rules too).
                    memberRepository.upsertMember(
                        associationId,
                        Member(
                            id = user.uid,
                            associationId = associationId,
                            fullName = fullName,
                            email = email,
                            role = MemberRole.MEMBER,
                            status = MemberStatus.PENDING_APPROVAL,
                            joinedAtEpochMs = System.currentTimeMillis()
                        )
                    )
                    _uiState.value = AuthUiState(isLoggedIn = true)
                },
                onFailure = { e ->
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = e.message)
                }
            )
        }
    }

    fun signOut() {
        authRepository.signOut()
        _uiState.value = AuthUiState(isLoggedIn = false)
    }
}
