package ca.gravityserenity.app.ui.screens.chat

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var editingLink by remember { mutableStateOf("") }

    Scaffold(topBar = { TopAppBar(title = { Text("Chat") }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when {
                state.isLoading -> CircularProgressIndicator()

                state.whatsappGroupLink != null -> {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "All association discussion happens in the WhatsApp group.",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(state.whatsappGroupLink))
                        context.startActivity(intent)
                    }) {
                        Text("Open WhatsApp Group")
                    }
                }

                // No link set yet — an admin/exec can paste the invite link here once.
                else -> {
                    Text(
                        "No WhatsApp group linked yet.",
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = editingLink,
                        onValueChange = { editingLink = it },
                        label = { Text("Paste WhatsApp group invite link") },
                        placeholder = { Text("https://chat.whatsapp.com/...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.saveLink(editingLink) },
                        enabled = editingLink.startsWith("https://chat.whatsapp.com/")
                    ) {
                        Text("Save Group Link")
                    }
                }
            }
        }
    }
}
