package ca.gravityserenity.app.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ca.gravityserenity.app.data.repository.AssociationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatUiState(
    val isLoading: Boolean = true,
    val whatsappGroupLink: String? = null,
    val isAdmin: Boolean = false // TODO: derive from current member's role once role lookup is wired here
)

class ChatViewModel(
    private val repository: AssociationRepository = AssociationRepository(),
    private val associationId: String = "demo-association"
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val association = repository.getAssociation(associationId)
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                whatsappGroupLink = association?.whatsappGroupLink
            )
        }
    }

    fun saveLink(link: String) {
        viewModelScope.launch {
            repository.setWhatsappGroupLink(associationId, link)
            _uiState.value = _uiState.value.copy(whatsappGroupLink = link)
        }
    }
}
