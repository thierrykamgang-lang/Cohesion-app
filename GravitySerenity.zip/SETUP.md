# Gravity Serenity — Setup

## What's built so far
- Full project scaffold (Gradle, Kotlin, Jetpack Compose, Material 3)
- Data models for **all 8 modules**: Members, Board/Committees, Dues, Tontines,
  Life Insurance, Cash Ledger, Votes/Surveys, Projects/Events/Meetings, Chat/Notifications
  (`data/model/`) — so every future module plugs into a consistent schema.
- **Members management** — fully working: list screen, add/edit screen, live
  Firestore sync, role assignment (Member / Committee Lead / Executive Board / Admin).
- App theme matching your purple/gold brand.

## What's not built yet
Auth/login screen, dues payments (Stripe), tontines, insurance, ledger, votes,
projects/events, chat, notifications UI, French localization. We'll add these
module by module the same way Members was built.

## To run this yourself

1. **Install Android Studio** (free): https://developer.android.com/studio
2. **Open the project**: File → Open → select the `GravitySerenity` folder
3. **Create a Firebase project** (free tier is enough for now):
   - Go to https://console.firebase.google.com → Add project
   - Add an Android app with package name `ca.gravityserenity.app`
   - Download the generated `google-services.json`
   - Drop it into `GravitySerenity/app/google-services.json` (same folder as `build.gradle.kts` for the app module)
4. **Enable Firestore**: In Firebase console → Build → Firestore Database → Create database (start in test mode for now, we'll lock down rules before launch)
5. **Enable Authentication**: Firebase console → Build → Authentication → get started (we'll wire up email/password or phone auth next)
6. Click **Run ▶** in Android Studio with an emulator or physical device connected

## Firestore data structure
```
associations/{associationId}/
  members/{memberId}
  boardPositions/{id}
  committees/{id}
  dues/{id}
  tontines/{id}
  ...
```
Everything is scoped under an association so this could later support multiple
associations in one deployment if needed.

## Next module to build
Your call — I'd suggest **Auth + login** next since every other screen needs
to know who's logged in, then whichever feature matters most to you day-to-day
(Dues is a common next pick since it ties to payments).
