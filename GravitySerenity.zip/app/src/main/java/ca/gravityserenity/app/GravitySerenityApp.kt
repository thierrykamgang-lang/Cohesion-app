package ca.gravityserenity.app

import android.app.Application

class GravitySerenityApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Firebase auto-initializes from google-services.json once you add it
        // (see SETUP.md — you'll drop your own file in app/).
    }
}
