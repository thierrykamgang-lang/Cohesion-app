package ca.gravityserenity.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import ca.gravityserenity.app.ui.navigation.GsNavGraph
import ca.gravityserenity.app.ui.theme.GravitySerenityTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GravitySerenityTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GsNavGraph()
                }
            }
        }
    }
}
