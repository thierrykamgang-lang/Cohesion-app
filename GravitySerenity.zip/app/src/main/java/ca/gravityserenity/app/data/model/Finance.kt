package ca.gravityserenity.app.data.model

/** Recurring membership dues, tied to a Stripe subscription/payment intent. */
data class DuesRecord(
    val id: String = "",
    val associationId: String = "",
    val memberId: String = "",
    val amountCents: Long = 0L,
    val currency: String = "cad",
    val periodLabel: String = "",       // e.g. "2026-08"
    val status: PaymentStatus = PaymentStatus.PENDING,
    val stripePaymentIntentId: String? = null,
    val paidAtEpochMs: Long? = null,
    val dueAtEpochMs: Long = 0L
)

enum class PaymentStatus { PENDING, PAID, FAILED, WAIVED, OVERDUE }

/**
 * A rotating-savings cycle (tontine). Each cycle has an ordered payout
 * queue; auctions let members bid to move up the queue.
 */
data class Tontine(
    val id: String = "",
    val associationId: String = "",
    val name: String = "",
    val contributionAmountCents: Long = 0L,
    val cyclePeriod: CyclePeriod = CyclePeriod.MONTHLY,
    val memberIds: List<String> = emptyList(),
    val payoutOrder: List<String> = emptyList(), // memberIds in payout sequence
    val currentCycleIndex: Int = 0,
    val startedAtEpochMs: Long = 0L
)

enum class CyclePeriod { WEEKLY, BIWEEKLY, MONTHLY }

data class TontineBid(
    val id: String = "",
    val tontineId: String = "",
    val cycleIndex: Int = 0,
    val memberId: String = "",
    val bidAmountCents: Long = 0L,  // amount member offers to forgo to receive payout sooner
    val submittedAtEpochMs: Long = 0L
)

data class TontineContribution(
    val id: String = "",
    val tontineId: String = "",
    val cycleIndex: Int = 0,
    val memberId: String = "",
    val status: PaymentStatus = PaymentStatus.PENDING,
    val paidAtEpochMs: Long? = null
)

data class LifeInsurancePolicy(
    val id: String = "",
    val associationId: String = "",
    val memberId: String = "",
    val coverageAmountCents: Long = 0L,
    val monthlyContributionCents: Long = 0L,
    val beneficiaryName: String = "", // NOTE: keep beneficiary contact details minimal/encrypted server-side
    val active: Boolean = true
)

data class InsuranceClaim(
    val id: String = "",
    val policyId: String = "",
    val memberId: String = "",
    val description: String = "",
    val status: ClaimStatus = ClaimStatus.SUBMITTED,
    val submittedAtEpochMs: Long = 0L,
    val resolvedAtEpochMs: Long? = null
)

enum class ClaimStatus { SUBMITTED, UNDER_REVIEW, APPROVED, DENIED, PAID }

/** A single entry in the association's multi-register cash ledger (for audit/reports). */
data class LedgerEntry(
    val id: String = "",
    val associationId: String = "",
    val registerName: String = "",  // e.g. "General", "Tontine", "Insurance"
    val amountCents: Long = 0L,     // positive = credit, negative = debit
    val description: String = "",
    val relatedMemberId: String? = null,
    val category: String = "",
    val recordedByMemberId: String = "",
    val recordedAtEpochMs: Long = 0L
)
