package ca.gravityserenity.app.data.model

data class Vote(
    val id: String = "",
    val associationId: String = "",
    val title: String = "",
    val description: String = "",
    val options: List<String> = emptyList(),
    val isAnonymous: Boolean = true,
    val opensAtEpochMs: Long = 0L,
    val closesAtEpochMs: Long = 0L,
    val createdByMemberId: String = ""
)

data class Ballot(
    val id: String = "",
    val voteId: String = "",
    val memberId: String = "",     // stored for eligibility checks even if isAnonymous hides it from other members
    val selectedOption: String = "",
    val submittedAtEpochMs: Long = 0L
)

data class Project(
    val id: String = "",
    val associationId: String = "",
    val name: String = "",
    val description: String = "",
    val budgetCents: Long = 0L,
    val spentCents: Long = 0L,
    val leadMemberId: String? = null,
    val status: ProjectStatus = ProjectStatus.PLANNING
)

enum class ProjectStatus { PLANNING, ACTIVE, COMPLETED, CANCELLED }

data class EventItem(
    val id: String = "",
    val associationId: String = "",
    val projectId: String? = null,
    val title: String = "",
    val startAtEpochMs: Long = 0L,
    val endAtEpochMs: Long = 0L,
    val location: String = "",
    val rsvpMemberIds: List<String> = emptyList(),
    val attendedMemberIds: List<String> = emptyList()
)

data class Meeting(
    val id: String = "",
    val associationId: String = "",
    val title: String = "",
    val heldAtEpochMs: Long = 0L,
    val minutesText: String = "",
    val attendeeMemberIds: List<String> = emptyList(),
    val reportDocUrl: String? = null
)

data class ChatMessage(
    val id: String = "",
    val threadId: String = "",       // groupId or "dm_<uidA>_<uidB>"
    val senderMemberId: String = "",
    val text: String = "",
    val sentAtEpochMs: Long = 0L
)

data class AppNotification(
    val id: String = "",
    val associationId: String = "",
    val recipientMemberId: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "",           // "dues", "vote", "event", "chat", "tontine"
    val read: Boolean = false,
    val createdAtEpochMs: Long = 0L
)
