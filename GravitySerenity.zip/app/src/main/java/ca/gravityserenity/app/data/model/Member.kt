package ca.gravityserenity.app.data.model

/**
 * A member of the association. This is the anchor entity — dues, votes,
 * tontine slots, insurance contributions, and event attendance all
 * reference memberId.
 */
data class Member(
    val id: String = "",                // Firestore doc id == Firebase Auth uid
    val associationId: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val photoUrl: String? = null,
    val role: MemberRole = MemberRole.MEMBER,
    val committeeIds: List<String> = emptyList(),
    val status: MemberStatus = MemberStatus.ACTIVE,
    val joinedAtEpochMs: Long = 0L,
    val preferredLanguage: String = "en" // "en" or "fr" — bilingual requirement
)

enum class MemberRole {
    MEMBER,
    COMMITTEE_LEAD,
    EXECUTIVE_BOARD,   // president, treasurer, secretary, etc.
    ADMIN              // full app control
}

enum class MemberStatus {
    ACTIVE,
    INACTIVE,
    PENDING_APPROVAL
}

/**
 * A named seat on the executive board (e.g. President, Treasurer).
 * Separate from MemberRole so an association can define its own board
 * structure without code changes.
 */
data class BoardPosition(
    val id: String = "",
    val associationId: String = "",
    val title: String = "",          // "Treasurer", "President", ...
    val memberId: String = "",
    val termStartEpochMs: Long = 0L,
    val termEndEpochMs: Long? = null
)

data class Committee(
    val id: String = "",
    val associationId: String = "",
    val name: String = "",
    val leadMemberId: String? = null,
    val memberIds: List<String> = emptyList()
)

/**
 * The top-level tenant. Every other collection is scoped under
 * associationId so one deployment can (eventually) host many associations.
 */
data class Association(
    val id: String = "",
    val name: String = "",
    val planTier: PlanTier = PlanTier.DISCOVERY,
    val memberLimit: Int = 30,
    val createdAtEpochMs: Long = 0L
)

enum class PlanTier { DISCOVERY, SOLIDARITY, COMMUNITY, ALLIANCE }
