package ca.gravityserenity.app.data.repository

import ca.gravityserenity.app.data.model.Member
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * All reads/writes for the Members module go through here.
 * Firestore path: associations/{associationId}/members/{memberId}
 */
class MemberRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private fun membersCollection(associationId: String) =
        db.collection("associations").document(associationId).collection("members")

    /** Live stream of every member in the association, for the list screen. */
    fun observeMembers(associationId: String): Flow<List<Member>> = callbackFlow {
        val registration = membersCollection(associationId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val members = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Member::class.java)?.copy(id = doc.id)
                } ?: emptyList()
                trySend(members)
            }
        awaitClose { registration.remove() }
    }

    suspend fun getMember(associationId: String, memberId: String): Member? {
        val doc = membersCollection(associationId).document(memberId).get().await()
        return doc.toObject(Member::class.java)?.copy(id = doc.id)
    }

    suspend fun upsertMember(associationId: String, member: Member) {
        val docId = member.id.ifBlank { membersCollection(associationId).document().id }
        membersCollection(associationId).document(docId).set(member.copy(id = docId)).await()
    }

    suspend fun deleteMember(associationId: String, memberId: String) {
        membersCollection(associationId).document(memberId).delete().await()
    }
}
