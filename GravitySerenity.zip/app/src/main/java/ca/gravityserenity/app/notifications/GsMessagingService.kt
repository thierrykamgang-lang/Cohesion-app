package ca.gravityserenity.app.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives push notifications for dues reminders, new votes, chat messages, etc.
 * TODO: build out actual notification channels + tap-through deep links once
 * the other modules exist.
 */
class GsMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        // TODO: show a system notification using message.notification / message.data
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // TODO: save token to the member's Firestore doc so the backend can target them
    }
}
