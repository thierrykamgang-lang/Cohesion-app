package ca.gravityserenity.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import ca.gravityserenity.app.ui.screens.members.MemberEditScreen
import ca.gravityserenity.app.ui.screens.members.MembersListScreen
import ca.gravityserenity.app.ui.screens.members.MembersViewModel

sealed class Screen(val route: String) {
    data object MembersList : Screen("members_list")
    data object MemberAdd : Screen("member_add")
    data object MemberEdit : Screen("member_edit/{memberId}") {
        fun createRoute(memberId: String) = "member_edit/$memberId"
        val arguments: List<NamedNavArgument> = listOf(
            navArgument("memberId") { type = NavType.StringType }
        )
    }
}

@Composable
fun GsNavGraph(navController: NavHostController = rememberNavController()) {
    // Shared ViewModel across list/edit so edits reflect immediately without a refetch.
    val membersViewModel: MembersViewModel = viewModel()

    NavHost(navController = navController, startDestination = Screen.MembersList.route) {

        composable(Screen.MembersList.route) {
            MembersListScreen(
                viewModel = membersViewModel,
                onMemberClick = { member ->
                    navController.navigate(Screen.MemberEdit.createRoute(member.id))
                },
                onAddMemberClick = { navController.navigate(Screen.MemberAdd.route) }
            )
        }

        composable(Screen.MemberAdd.route) {
            MemberEditScreen(
                existingMember = null,
                viewModel = membersViewModel,
                onDone = { navController.popBackStack() }
            )
        }

        composable(Screen.MemberEdit.route, arguments = Screen.MemberEdit.arguments) { backStackEntry ->
            val memberId = backStackEntry.arguments?.getString("memberId")
            val state by membersViewModel.uiState.collectAsState()
            val existing = remember(memberId, state.members) {
                state.members.find { it.id == memberId }
            }

            MemberEditScreen(
                existingMember = existing,
                viewModel = membersViewModel,
                onDone = { navController.popBackStack() }
            )
        }
    }
}
