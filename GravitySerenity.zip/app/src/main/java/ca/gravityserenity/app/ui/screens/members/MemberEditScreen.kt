package ca.gravityserenity.app.ui.screens.members

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ca.gravityserenity.app.data.model.Member
import ca.gravityserenity.app.data.model.MemberRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberEditScreen(
    existingMember: Member?,
    viewModel: MembersViewModel = viewModel(),
    onDone: () -> Unit
) {
    var fullName by remember { mutableStateOf(existingMember?.fullName ?: "") }
    var email by remember { mutableStateOf(existingMember?.email ?: "") }
    var phone by remember { mutableStateOf(existingMember?.phone ?: "") }
    var role by remember { mutableStateOf(existingMember?.role ?: MemberRole.MEMBER) }
    var roleMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text(if (existingMember == null) "Add Member" else "Edit Member") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full name") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone") },
                modifier = Modifier.fillMaxWidth()
            )

            ExposedDropdownMenuBox(
                expanded = roleMenuExpanded,
                onExpandedChange = { roleMenuExpanded = it }
            ) {
                OutlinedTextField(
                    value = role.name,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Role") },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = roleMenuExpanded,
                    onDismissRequest = { roleMenuExpanded = false }
                ) {
                    MemberRole.entries.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.name) },
                            onClick = {
                                role = option
                                roleMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            Button(
                onClick = {
                    viewModel.saveMember(existingMember, fullName, email, phone, role)
                    onDone()
                },
                enabled = fullName.isNotBlank() && email.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save")
            }
        }
    }
}
