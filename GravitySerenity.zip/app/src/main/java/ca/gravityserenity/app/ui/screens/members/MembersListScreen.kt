package ca.gravityserenity.app.ui.screens.members

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ca.gravityserenity.app.data.model.Member
import ca.gravityserenity.app.data.model.MemberRole

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MembersListScreen(
    viewModel: MembersViewModel = viewModel(),
    onMemberClick: (Member) -> Unit,
    onAddMemberClick: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Members") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddMemberClick) {
                Icon(Icons.Default.Add, contentDescription = "Add member")
            }
        }
    ) { padding ->
        when {
            state.isLoading -> Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }

            state.members.isEmpty() -> Box(
                Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) { Text("No members yet — tap + to add your first member.") }

            else -> LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(state.members, key = { it.id }) { member ->
                    MemberRow(member = member, onClick = { onMemberClick(member) })
                }
            }
        }
    }
}

@Composable
private fun MemberRow(member: Member, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, contentDescription = null)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(member.fullName, style = MaterialTheme.typography.titleMedium)
                Text(member.email, style = MaterialTheme.typography.bodySmall)
            }
            AssistChip(onClick = {}, label = { Text(member.role.label()) })
        }
    }
}

private fun MemberRole.label(): String = when (this) {
    MemberRole.MEMBER -> "Member"
    MemberRole.COMMITTEE_LEAD -> "Committee Lead"
    MemberRole.EXECUTIVE_BOARD -> "Executive Board"
    MemberRole.ADMIN -> "Admin"
}
