package ca.gravityserenity.app.ui.screens.members

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ca.gravityserenity.app.data.model.Member
import ca.gravityserenity.app.data.model.MemberRole
import ca.gravityserenity.app.data.model.MemberStatus
import ca.gravityserenity.app.data.repository.MemberRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class MembersUiState(
    val members: List<Member> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

class MembersViewModel(
    private val repository: MemberRepository = MemberRepository(),
    private val associationId: String = "demo-association" // TODO: pull from logged-in user's session
) : ViewModel() {

    private val _uiState = MutableStateFlow(MembersUiState())
    val uiState: StateFlow<MembersUiState> = _uiState.asStateFlow()

    init {
        loadMembers()
    }

    private fun loadMembers() {
        viewModelScope.launch {
            repository.observeMembers(associationId)
                .collect { members ->
                    _uiState.value = _uiState.value.copy(members = members, isLoading = false)
                }
        }
    }

    fun saveMember(
        existing: Member?,
        fullName: String,
        email: String,
        phone: String,
        role: MemberRole
    ) {
        viewModelScope.launch {
            val member = (existing ?: Member(associationId = associationId)).copy(
                fullName = fullName,
                email = email,
                phone = phone,
                role = role,
                status = existing?.status ?: MemberStatus.ACTIVE,
                joinedAtEpochMs = existing?.joinedAtEpochMs ?: System.currentTimeMillis()
            )
            repository.upsertMember(associationId, member)
        }
    }

    fun deleteMember(memberId: String) {
        viewModelScope.launch {
            repository.deleteMember(associationId, memberId)
        }
    }
}
