package ca.gravityserenity.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Pulled from the Gravity Serenity brand: deep purple bg, violet cards, gold accent
val GsPurpleDark = Color(0xFF2B1B6B)
val GsPurpleCard = Color(0xFF3D2C8D)
val GsViolet = Color(0xFF7B5CE0)
val GsGold = Color(0xFFF5B93D)
val GsGreenCheck = Color(0xFF3DDC84)

private val GsColorScheme = darkColorScheme(
    primary = GsViolet,
    secondary = GsGold,
    background = GsPurpleDark,
    surface = GsPurpleCard,
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun GravitySerenityTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = GsColorScheme,
        content = content
    )
}
